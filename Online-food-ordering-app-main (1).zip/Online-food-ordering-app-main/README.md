# Online-food-ordering-app
Online Food Ordering App like Swiggy and Zomato built using Html, CSS and Pure JavaScript. No frameworks or libraries <br/><br/><br/>

Live Demo => https://shivamjain1.github.io/Online-food-ordering-app  <br/><br/><br/>

![image](https://user-images.githubusercontent.com/28086341/102119032-855d4280-3e66-11eb-8070-59a73b68a918.png)

<br/>

Functionalities Implemented <br/>
* Search of a Restaurant with <b>Debouncing</b>
* Sorting of Restaurant
  * Sort by Rating
  * Sort by ETA
* Mark Restaurant as Favourite


<b>Pull Requests Are Welcome:</b> This project is built part of my UI Tech round preparation. While I do appreciate if people trying to make some things prettier or adding new features.
